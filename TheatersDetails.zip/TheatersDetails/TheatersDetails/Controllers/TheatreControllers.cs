﻿using Microsoft.AspNetCore.Mvc;
using TheatersDetails.Data;
using TheatersDetails.Models;
using TheatersDetails.Models.Entities;

namespace TheatersDetails.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TheatreControllers : ControllerBase
    {
        private readonly ApplicationContext dbContext;
        public TheatreControllers(ApplicationContext dbContext)
        {
            this.dbContext = dbContext;
        }
        [HttpGet]
        public IActionResult GetAllEmployees()
        {
            return Ok(dbContext.Property.ToList());
        }
        [HttpGet]
        [Route("{id:guid}")]
        public IActionResult GetById(Guid id)
        {
            var employee = dbContext.Property.Find(id);
            if (employee is null)
            {
                return NotFound();
            }
            return Ok(employee);
        }
        [HttpPost]
        public IActionResult AddTheatre(AddTheatres addDbo)
        {
            var Entity = new Theatre()
            {
                TheatreName = addDbo.TheatreName,
                Nscreens = addDbo.Nscreens,
                Place = addDbo.Place,
                Collections = addDbo.Collections
            };
            dbContext.Property.Add(Entity);
            dbContext.SaveChanges();
            return Ok(Entity);
        }
        [HttpPut]
        [Route("{id:guid}")]
        public IActionResult UpdateEmployeeDto(UpdateTheatres updateEmployeeDbo, Guid id)
        {
            var employee = dbContext.Property.Find(id);
            if (employee is null)
            {
                return NotFound();
            }
            employee.TheatreName = updateEmployeeDbo.TheatreName;
            employee.Nscreens = updateEmployeeDbo.Nscreens;
            employee.Place = updateEmployeeDbo.Place;
            employee.Collections = updateEmployeeDbo.Collections;
            dbContext.SaveChanges();
            return Ok(employee);


        }
    }
}
