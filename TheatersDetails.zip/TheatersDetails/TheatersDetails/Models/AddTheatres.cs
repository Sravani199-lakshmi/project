﻿namespace TheatersDetails.Models
{
    public class AddTheatres
    {
        public Guid Id { get; set; }
        public required string TheatreName { get; set; }
        public required int Nscreens { get; set; }
        public required string Place { get; set; }
        public decimal Collections { get; set; }
    }
}
