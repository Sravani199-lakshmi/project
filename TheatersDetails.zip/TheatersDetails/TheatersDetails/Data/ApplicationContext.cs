﻿using Microsoft.EntityFrameworkCore;
using TheatersDetails.Models.Entities;

namespace TheatersDetails.Data
{
    public class ApplicationContext : DbContext
    {
        public ApplicationContext(DbContextOptions<ApplicationContext> options) : base(options)
        {

        }
        public DbSet<Theatre> Property { set; get; }
    }
}
